package com.capstone.persistence;

import java.util.List;

import com.capstone.domain.BoardVO;

public interface BoardDAO {
	
	//작성
	public void write(BoardVO vo) throws Exception;
	
	//수정
	public void modify(BoardVO vo) throws Exception;
		
	//삭제
	public void delete(int bno) throws Exception;
	
	//목록
	public List<BoardVO> list() throws Exception;
}