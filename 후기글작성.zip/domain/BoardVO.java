package com.capstone.domain;

import java.util.Date;

public class BoardVO {
	
	private int bno;
	private String post;
	private String starcheck;
	private String writer;
	private Date regDate;
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public String getPost() {
		return post;
	}
	public void setPost(String post) {
		this.post = post;
	}
	public String getStarcheck() {
		return starcheck;
	}
	public void setStarcheck(String starcheck) {
		this.starcheck = starcheck;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	
	
	
}