package com.capstone.service;

import java.util.List;

import com.capstone.domain.FaqVO;

public interface FaqService {
	
	//작성
	public void write(FaqVO vo) throws Exception;
	
	//조회
	public FaqVO read(int bno) throws Exception;
	
	//수정
	public void modify(FaqVO vo) throws Exception;
	
	//삭제
	public void delete(int bno) throws Exception;
	
	//목록
	public List<FaqVO> list() throws Exception;
}