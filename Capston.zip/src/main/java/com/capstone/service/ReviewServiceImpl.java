package com.capstone.service;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.capstone.persistence.ReviewDAO;

@Service
public class ReviewServiceImpl implements ReviewService{

	@Inject
	private ReviewDAO dao;
	
	//후기 작성
	
	
	//후기 수정
		
		
	//후기 삭제
		
		
	//후기 관리 화면 출력
		
		
	//상품상세 대한 후기 출력
}
