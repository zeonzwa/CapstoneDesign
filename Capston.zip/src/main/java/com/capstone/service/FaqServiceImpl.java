package com.capstone.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.capstone.domain.FaqVO;
import com.capstone.persistence.FaqDAO;

@Repository
public class FaqServiceImpl implements FaqService {
	
	@Inject
	private FaqDAO dao;

	//작성
	@Override
	public void write(FaqVO vo) throws Exception {
		dao.write(vo);
	}

	//읽기
	@Override
	public FaqVO read(int bno) throws Exception {
		return dao.read(bno);
	}

	//수정
	@Override
	public void modify(FaqVO vo) throws Exception {
		dao.modify(vo);
	}

	//삭제
	@Override
	public void delete(int bno) throws Exception {
		dao.delete(bno);
	}

	//목록
	@Override
	public List<FaqVO> list() throws Exception {
		return dao.list();
	}

}
