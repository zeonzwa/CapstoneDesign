package com.capstone.controller;

import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capstone.domain.FaqVO;
import com.capstone.service.FaqService;

@Controller
@RequestMapping(value="/move/*")
public class FaqController {
	
	private static final Logger logger = LoggerFactory.getLogger(FaqController.class);
	 
	 @Inject
	 FaqService service;
	 
	 // 글 작성 get
	 @RequestMapping(value = "/faq_write", method = RequestMethod.GET)
	 public void getWrite() throws Exception {
	  logger.info("get write");
	 }

	 // 글 작성 post
	 @RequestMapping(value = "/faq_write", method = RequestMethod.POST)
	 public String postWrite(FaqVO vo) throws Exception {
	  logger.info("post write");
	  
	  service.write(vo);
	  
	  return "redirect:/move/faq1";
	 }
	 
	// 글 목록
	 @RequestMapping(value = "/faq1", method = RequestMethod.GET)
	 public void list(Model model) throws Exception {
	  logger.info("get list");
	  
	  List<FaqVO> list = service.list();
	  
	  model.addAttribute("list", list);
	 }
	 
	 // 글 수 정
	 @RequestMapping(value = "/faq_modify", method = RequestMethod.GET)
	 public void getModify(@RequestParam("bno") int bno, Model model) throws Exception {	  
	  FaqVO vo = service.read(bno);
	  
	  model.addAttribute("read", vo);
	  
	 }
	 
	 //글 수정 POST
	 @RequestMapping(value = "/faq_modify", method = RequestMethod.POST)
	 public String postModify(FaqVO vo) throws Exception{
		 logger.info("post modify");
		 service.modify(vo);
		 return "redirect:/admin/faq1";
		 
	 }
	 
	 // 글 삭제
	 @RequestMapping(value = "/faq_delete", method = RequestMethod.GET)
	 public void getDelete(@RequestParam("bno") int bno, Model model) throws Exception {
	  logger.info("get delete");
	    
	  model.addAttribute("delete", bno);
	  
	 }

	 // 글 삭제  POST
	 @RequestMapping(value = "/faq_delete", method = RequestMethod.POST)
	 public String postDelete(@RequestParam("bno") int bno) throws Exception {
	  logger.info("post delete");
	    
	  service.delete(bno);
	  
	  return "redirect:/move/faq1";
	 }
}