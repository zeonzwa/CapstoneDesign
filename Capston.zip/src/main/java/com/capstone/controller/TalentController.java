package com.capstone.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/talent/*")
public class TalentController {

	private static final Logger logger = LoggerFactory.getLogger(TalentController.class);
	
	
	//재능 판매 등록 get
	
	
	//재능 판매 등록 post
	
	
	//재능 판매 수정 get
	
	
	//재능 판매 수정 post
	
	
	//재능 판매 삭제
	
	
	//재능 판매 화면 출력
	
	
	//재능 판매 상세 조회
	
	
//////////////여기까지 재능 판매 관련
	//재능 구매 등록 get
	
	
	//재능 구매 등록 post
		
		
	//재능 구매 수정 get
		
		
	//재능 구매 수정 post
		
	
	//재능 구매 삭제
		
		
	//재능 구매 화면 출력
		
		
	//재능 구매 상세 조회
	
//////////////여기까지 재능 구매 관련
	
	
	
	
	
	
	
	
	
}
