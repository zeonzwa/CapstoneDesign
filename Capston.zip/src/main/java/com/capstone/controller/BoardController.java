package com.capstone.controller;

import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capstone.domain.BoardVO;
import com.capstone.service.BoardService;

@Controller
@RequestMapping(value="/admin/*")
public class BoardController {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	 
	 @Inject
	 BoardService service;
	 
	 // 글 작성 get
	 @RequestMapping(value = "/review_write", method = RequestMethod.GET)
	 public void getWrite() throws Exception {
	  logger.info("get write");
	 }

	 // 글 작성 post
	 @RequestMapping(value = "/review_write", method = RequestMethod.POST)
	 public String postWrite(BoardVO vo) throws Exception {
	  logger.info("post write");
	  
	  service.write(vo);
	  
	  return "redirect:/admin/review_list";
	 }
	 
	// 글 목록
	 @RequestMapping(value = "/review_list", method = RequestMethod.GET)
	 public void list(Model model) throws Exception {
	  logger.info("get list");
	  
	  List<BoardVO> list = service.list();
	  
	  model.addAttribute("list", list);
	 }
	 
	 // 글 수 정
	 @RequestMapping(value = "/review_modify", method = RequestMethod.GET)
	 public void getModify(@RequestParam("bno") int bno, Model model) throws Exception {	  
	  BoardVO vo = service.read(bno);
	  
	  model.addAttribute("read", vo);
	  
	 }
	 
	 //글 수정 POST
	 @RequestMapping(value = "/review_modify", method = RequestMethod.POST)
	 public String postModify(BoardVO vo) throws Exception{
		 logger.info("post modify");
		 service.modify(vo);
		 return "redirect:/admin/review_list";
		 
	 }
	 
	 // 글 삭제
	 @RequestMapping(value = "/review_delete", method = RequestMethod.GET)
	 public void getDelete(@RequestParam("bno") int bno, Model model) throws Exception {
	  logger.info("get delete");
	    
	  model.addAttribute("delete", bno);
	  
	 }

	 // 글 삭제  POST
	 @RequestMapping(value = "/review_delete", method = RequestMethod.POST)
	 public String postDelete(@RequestParam("bno") int bno) throws Exception {
	  logger.info("post delete");
	    
	  service.delete(bno);
	  
	  return "redirect:/admin/review_list";
	 }
}