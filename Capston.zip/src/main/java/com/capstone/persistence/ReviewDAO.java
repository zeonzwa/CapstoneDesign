package com.capstone.persistence;

public interface ReviewDAO {

	//후기 작성
	
	
	//후기 수정
	
	
	//후기 삭제
	
	
	//후기 관리 화면 출력
	
	
	//상품상세 대한 후기 출력
}
