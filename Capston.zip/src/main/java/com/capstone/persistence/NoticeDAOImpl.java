package com.capstone.persistence;

import java.util.List;

import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.capstone.domain.NoticeVO;

@Repository
public class NoticeDAOImpl implements NoticeDAO {
	
	

	@Override
	public void write(NoticeVO vo) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public NoticeVO read(int bno) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void modify(NoticeVO vo) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int bno) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<NoticeVO> list() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
