package com.capstone.persistence;

import java.util.List;

import com.capstone.domain.NoticeVO;

public interface NoticeDAO {
	//작성
	public void write(NoticeVO vo) throws Exception;
	
	//조회
	public NoticeVO read(int bno) throws Exception;
	
	//수정
	public void modify(NoticeVO vo) throws Exception;
	
	//삭제
	public void delete(int bno) throws Exception;
	
	//읽기
	public List<NoticeVO> list() throws Exception;
}