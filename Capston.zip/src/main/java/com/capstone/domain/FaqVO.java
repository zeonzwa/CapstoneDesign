package com.capstone.domain;

import java.util.Date;

public class FaqVO {
	private String FAQ_TITLE;
	private String FAQ_KINDS;
	private String FAQ_CONTENT;
	private Date FAQ_DATE;
	private int bno;
	public String getFAQ_TITLE() {
		return FAQ_TITLE;
	}
	public void setFAQ_TITLE(String fAQ_TITLE) {
		FAQ_TITLE = fAQ_TITLE;
	}
	public String getFAQ_KINDS() {
		return FAQ_KINDS;
	}
	public void setFAQ_KINDS(String fAQ_KINDS) {
		FAQ_KINDS = fAQ_KINDS;
	}
	public String getFAQ_CONTENT() {
		return FAQ_CONTENT;
	}
	public void setFAQ_CONTENT(String fAQ_CONTENT) {
		FAQ_CONTENT = fAQ_CONTENT;
	}
	public Date getFAQ_DATE() {
		return FAQ_DATE;
	}
	public void setFAQ_DATE(Date fAQ_DATE) {
		FAQ_DATE = fAQ_DATE;
	}
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	
	
}