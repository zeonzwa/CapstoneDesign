package com.capstone.domain;

import java.util.Date;

public class Talent_B_VO {
	
	private String talb_Code;
	private String talb_Title;
	private String talb_Kinds;
	private String talb_Content;
	private String phone_Num;
	private Date talb_Date;
	private String talb_Id;
	
	public String getTalb_Id() {
		return talb_Id;
	}
	public void setTalb_Id(String talb_Id) {
		this.talb_Id = talb_Id;
	}
	public String getTalb_Code() {
		return talb_Code;
	}
	public void setTalb_Code(String talb_Code) {
		this.talb_Code = talb_Code;
	}
	public String getTalb_Title() {
		return talb_Title;
	}
	public void setTalb_Title(String talb_Title) {
		this.talb_Title = talb_Title;
	}
	public String getTalb_Kinds() {
		return talb_Kinds;
	}
	public void setTalb_Kinds(String talb_Kinds) {
		this.talb_Kinds = talb_Kinds;
	}
	public String getTalb_Content() {
		return talb_Content;
	}
	public void setTalb_Content(String talb_Content) {
		this.talb_Content = talb_Content;
	}
	public String getPhone_Num() {
		return phone_Num;
	}
	public void setPhone_Num(String phone_Num) {
		this.phone_Num = phone_Num;
	}
	public Date getTalb_Date() {
		return talb_Date;
	}
	public void setTalb_Date(Date talb_Date) {
		this.talb_Date = talb_Date;
	}
	
	
	
}
