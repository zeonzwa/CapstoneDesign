package com.capstone.domain;

import java.util.Date;

public class Goods_B_VO {
	private int goodsb_Code;
	private String goodsb_Title;
	private String goodsb_Cate;
	private String goodsb_Price;
	private String goodsb_Des;
	private String phone_Num;
	private Date goodsb_Date;
	private String goodsb_Id;
	public int getGoodsb_Code() {
		return goodsb_Code;
	}
	public void setGoodsb_Code(int goodsb_Code) {
		this.goodsb_Code = goodsb_Code;
	}
	public String getGoodsb_Title() {
		return goodsb_Title;
	}
	public void setGoodsb_Title(String goodsb_Title) {
		this.goodsb_Title = goodsb_Title;
	}
	public String getGoodsb_Cate() {
		return goodsb_Cate;
	}
	public void setGoodsb_Cate(String goodsb_Cate) {
		this.goodsb_Cate = goodsb_Cate;
	}
	public String getGoodsb_Price() {
		return goodsb_Price;
	}
	public void setGoodsb_Price(String goodsb_Price) {
		this.goodsb_Price = goodsb_Price;
	}
	public String getGoodsb_Des() {
		return goodsb_Des;
	}
	public void setGoodsb_Des(String goodsb_Des) {
		this.goodsb_Des = goodsb_Des;
	}
	public String getPhone_Num() {
		return phone_Num;
	}
	public void setPhone_Num(String phone_Num) {
		this.phone_Num = phone_Num;
	}
	public Date getGoodsb_Date() {
		return goodsb_Date;
	}
	public void setGoodsb_Date(Date goodsb_Date) {
		this.goodsb_Date = goodsb_Date;
	}
	public String getGoodsb_Id() {
		return goodsb_Id;
	}
	public void setGoodsb_Id(String goodsb_Id) {
		this.goodsb_Id = goodsb_Id;
	}
	
	
	
}
