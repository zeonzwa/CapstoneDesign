package com.capstone.domain;

import java.util.Date;

public class Talent_S_VO {

	private String tals_Code;
	private String tals_Title;
	private String tals_Kinds;
	private String tals_Content;
	private int tals_Price;
	private String tals_Term;
	private String phone_Num;
	private Date tals_Date;
	private String tals_Id;
	
	public String getTals_Id() {
		return tals_Id;
	}
	public void setTals_Id(String tals_Id) {
		this.tals_Id = tals_Id;
	}
	public String getTals_Code() {
		return tals_Code;
	}
	public void setTals_Code(String tals_Code) {
		this.tals_Code = tals_Code;
	}
	public String getTals_Title() {
		return tals_Title;
	}
	public void setTals_Title(String tals_Title) {
		this.tals_Title = tals_Title;
	}
	public String getTals_Kinds() {
		return tals_Kinds;
	}
	public void setTals_Kinds(String tals_Kinds) {
		this.tals_Kinds = tals_Kinds;
	}
	public String getTals_Content() {
		return tals_Content;
	}
	public void setTals_Content(String tals_Content) {
		this.tals_Content = tals_Content;
	}
	public int getTals_Price() {
		return tals_Price;
	}
	public void setTals_Price(int tals_Price) {
		this.tals_Price = tals_Price;
	}
	public String getTals_Term() {
		return tals_Term;
	}
	public void setTals_Term(String tals_Term) {
		this.tals_Term = tals_Term;
	}
	public String getPhone_Num() {
		return phone_Num;
	}
	public void setPhone_Num(String phone_Num) {
		this.phone_Num = phone_Num;
	}
	public Date getTals_Date() {
		return tals_Date;
	}
	public void setTals_Date(Date tals_Date) {
		this.tals_Date = tals_Date;
	}
	
	
}
